/*
* HelloColdFusion (very simple Java CFX)
*
* Copyright (c) 2002 Macromedia Corp. All Rights Reserved.
*
* Tag that prints a personalized greeting. The attributes of this
* tag are as follows:
*
* NAME   Name to use for printing personalized greeting.
*
* For examle, to print a greeting to "Robert", you would use the 
* following CFML code:
*
* <CFX_HelloColdFusion NAME="Robert">
*
*/

import com.allaire.cfx.* ;
import java.util.HashMap;
import java.util.Iterator;
import java.awt.image.BufferedImage ;
import com.sun.image.codec.jpeg.JPEGCodec ;
import com.sun.image.codec.jpeg.JPEGImageEncoder ;
import com.sun.image.codec.jpeg.ImageFormatException ;
import java.awt.Graphics2D;
import java.io.FileOutputStream ;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.IOException ;
import java.awt.Color ;

public class DrawTree1 implements CustomTag
{

    class StringHashMap extends HashMap {
        public StringHashMap(){super();}
        public String get(String key){
            if (super.get(key)==null) return "";
            return super.get(key).toString();
        }
        
    }
    
    Person readPerson(StringHashMap parms, String person){
      Person p = new Person(parms.get(person+"Name"),"", parms.get(person+"Gender"));
      return p;
    }
  
  public Person readPerson(StringHashMap parms, String personName, String relation, String gender, java.util.Map m){
  Person ret = new Person(parms.get(personName + "Name"), m.get(relation).toString(), gender);
  ret.stillLiving = !"No".equals(parms.get(personName + "StillLiving"));
  ret.isTwin = "Yes".equals(parms.get(personName + "IsTwin"));
  ret.highlighted= "Yes".equals(parms.get(personName + "Highlighted"));
  ret.setLanguageMap(m);
  for ( int lcv = 0; lcv < Person.fieldNames.length;lcv++){
    ret.fields.put(Person.fieldNames[lcv], parms.get(personName + Person.fieldNames[lcv]).trim());
  }
  //System.out.println(personName + parms.get(personName + "IsTwin"));
  return ret;
}
    
  
   public void processRequest( Request request, Response response ) 		
      throws Exception
   {
       boolean showNames="1".equals(request.getAttribute("showNames"));
       StringHashMap parms = new StringHashMap();

        if ("1".equals(request.getAttribute("debug"))){
          response.write("This is version 1.35");
        }

       if (request.getAttribute("spanishImageRoot")!=null){
           Person.spanishImageRoot = request.getAttribute("spanishImageRoot");
       }

       if (request.getAttribute("imageRoot")!=null){
           Person.imageRoot = request.getAttribute("imageRoot");
           Person.loadImages();
       }

      // -------   Read Parms from query ---------
      java.util.HashMap languageStrings = Person.englishStrings;         
      if ("spanish".equals(request.getAttribute("language"))){
          languageStrings = Person.spanishStrings;
      }
      Query q = request.getQuery();
      for (int lcv = 1;lcv <= q.getRowCount();lcv++){
        parms.put(q.getData(lcv,1), q.getData(lcv,2));
        if ("1".equals(request.getAttribute("debug"))){
          response.write(q.getData(lcv,1) + "=" +q.getData(lcv,2) + "<BR>");
        }
      }

//      if(true) return;
     
    java.util.HashMap people = new java.util.HashMap();
    java.util.ArrayList selfTwins = new java.util.ArrayList();
    java.util.ArrayList motherTwins = new java.util.ArrayList();
    java.util.ArrayList fatherTwins = new java.util.ArrayList();
    java.util.ArrayList maternalHalfSiblings = new ArrayList();
    java.util.ArrayList paternalHalfSiblings = new ArrayList();
  Person firstGen2 = null;
  Person firstGen3 = null;
    
//    Father's family
  Person father = readPerson(parms,"father", "Father", "Male", languageStrings);
  father.setAutoDrawChildren(false);

    
  people.put ("paternalGrandfather",readPerson(parms,"paternalGrandfather", "PaternalGrandfather","Male",languageStrings));
  people.put ("paternalGrandmother",readPerson(parms, "paternalGrandmother","PaternalGrandmother", "Female",languageStrings));

  ((Person) people.get("paternalGrandfather")).spouse= ((Person) people.get("paternalGrandmother"));


  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("fathersSister"));lcv++){
    Person paternalAunt = readPerson(parms, "fathersSister" + lcv, "FathersSister", "Female",languageStrings);

    people.put ("fathersSister" + lcv , paternalAunt);  
    ((Person) people.get("paternalGrandfather")).children.add(paternalAunt);
  }

  if (father.isTwin){
    fatherTwins.add(father);
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("fathersBrother"));lcv++){
    Person paternalUncle = readPerson(parms,"fathersBrother" + lcv, "FathersBrother", "Male",languageStrings);
    if (!paternalUncle.isTwin){
        if (firstGen2==null){
            firstGen2 = paternalUncle;
        }
      people.put ("fathersBrother" + lcv , paternalUncle);  
      ((Person) people.get("paternalGrandfather")).children.add(paternalUncle);
    }
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("fathersBrother"));lcv++){
    Person paternalUncle = readPerson(parms,"fathersBrother" + lcv, "FathersBrother", "Male",languageStrings);
    if (paternalUncle.isTwin){
        if (firstGen2==null){
            firstGen2 = paternalUncle;
        }
      people.put ("fathersBrother" + lcv , paternalUncle);  
      ((Person) people.get("paternalGrandfather")).children.add(paternalUncle);
      fatherTwins.add(paternalUncle);
    }
  }
    if (firstGen2==null){
        firstGen2 = father;
    }

//  Mother's Family

  people.put ("maternalGrandfather",readPerson(parms,"maternalGrandfather","MaternalGrandfather","Male",languageStrings));
  people.put ("maternalGrandmother",readPerson(parms,"maternalGrandmother", "MaternalGrandmother","Female",languageStrings));

Person mother = readPerson(parms,"mother", "Mother", "Female",languageStrings);  
((Person)people.get("maternalGrandfather")).children.add(mother);

  ((Person) people.get("maternalGrandfather")).spouse= ((Person) people.get("maternalGrandmother"));

  
  if (mother.isTwin){
    motherTwins.add(mother);
  }
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("mothersSister"));lcv++){
    Person maternalAunt = readPerson(parms,"mothersSister" + lcv, "MothersSister", "Female",languageStrings);
    if (maternalAunt.isTwin){
      people.put ("mothersSister" + lcv , maternalAunt);
      ((Person) people.get("maternalGrandfather")).children.add(maternalAunt);
      motherTwins.add(maternalAunt);
    }
  }
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("mothersSister"));lcv++){
    Person maternalAunt = readPerson(parms,"mothersSister" + lcv, "MothersSister", "Female",languageStrings);
    if (!maternalAunt.isTwin){
      people.put ("mothersSister" + lcv , maternalAunt);
      ((Person) people.get("maternalGrandfather")).children.add(maternalAunt);
    }
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("mothersBrother"));lcv++){
    Person maternalUncle = readPerson(parms,"mothersBrother" + lcv, "MothersBrother", "Male", languageStrings);

    people.put ("mothersBrother" + lcv , maternalUncle);  
    ((Person) people.get("maternalGrandfather")).children.add(maternalUncle);
  }

  int cousinCount = 0;
//  Cousins

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("maleCousin"));lcv++){
    Person cousin = readPerson( parms, "maleCousin" + lcv, "MaleCousin", "Male",languageStrings);

    people.put ("maleCousin" + lcv , cousin);  
    Person parent = ((Person) people.get(parms.get("maleCousin"+ lcv + "Parent")));
    if (parent!= null){
      parent.children.add(cousin);
      cousinCount++;
    }
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("femaleCousin"));lcv++){
    Person cousin = readPerson(parms,"femaleCousin" + lcv, "FemaleCousin", "Female",languageStrings);

    people.put ("femaleCousin" + lcv , cousin);  
    Person parent = ((Person) people.get(parms.get("femaleCousin"+ lcv + "Parent")));
    if (parent!= null){
      parent.children.add(cousin);
      cousinCount++;
    }
  }

//  Self family

  Person self = readPerson(parms, "self", "Self", parms.get("selfGender"),languageStrings);

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("son"));lcv++){
    Person son = readPerson(parms, "son" + lcv, "Son", "Male",languageStrings);
    people.put ("son" + lcv , son);
    self.children.add(son);
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("daughter"));lcv++){
    Person daughter = readPerson(parms,"daughter" + lcv, "Daughter", "Female", languageStrings);
    people.put ("daughter" + lcv , daughter);
    self.children.add(daughter);
  }

  Person firstSibling = null;
  Person lastSibling = null;
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("brother"));lcv++){
    Person brother = readPerson(parms, "brother" + lcv , "Brother", "Male",languageStrings);
    if (brother.isTwin) continue;
    if (firstSibling==null) firstSibling = brother;
    people.put ("brother" + lcv , brother);
    father.children.add(brother);
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("brother"));lcv++){
    Person brother = readPerson(parms, "brother" + lcv, "Brother", "Male",languageStrings);
    if (!brother.isTwin) continue;
    selfTwins.add(brother);
    if (firstSibling==null) firstSibling = brother;
    people.put ("brother" + lcv , brother);
    father.children.add(brother);
  }
  selfTwins.add(self);
  father.children.add(self);
  lastSibling=self;
  if (firstSibling==null){firstSibling=self;}

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("sister"));lcv++){
    Person sister = readPerson(parms, "sister" + lcv ,"Sister", "Female",languageStrings);
    if (!sister.isTwin) continue;
    selfTwins.add(sister);
    lastSibling=sister;
    people.put ("sister" + lcv , sister);
    father.children.add(sister);
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("sister"));lcv++){
    Person sister = readPerson(parms, "sister" + lcv ,"Sister", "Female",languageStrings);
    if (sister.isTwin) continue;
    lastSibling=sister;
    people.put ("sister" + lcv , sister);
    father.children.add(sister);
  }

//  Nephews

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("nephew"));lcv++){
    Person nephew = readPerson(parms,"nephew" + lcv, "Nephew", "Male",languageStrings);

    people.put ("nephew" + lcv , nephew);  
    Person parent = ((Person) people.get(parms.get("nephew"+ lcv + "Parent")));
    if (parent!= null){
      parent.children.add(nephew);
    }
  }

//  Nieces

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("niece"));lcv++){
    Person niece = readPerson(parms,"niece" + lcv, "Niece", "Female",languageStrings);

    people.put ("niece" + lcv , niece);  
    Person parent = ((Person) people.get(parms.get("niece"+ lcv + "Parent")));
    if (parent!= null){
      parent.children.add(niece);
    }
  }



((Person)people.get("paternalGrandfather")).children.add(father); 

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("halfBrother")); lcv ++){
    String gender =  "Male";
    String relation = "Half-Brother"; 
    Person halfSibling = readPerson(parms, "halfBrother" + lcv, relation, gender,languageStrings);
    if ( parms.get("halfBrother" + lcv + "Parent").equals("father") ) {
      paternalHalfSiblings.add(halfSibling);
    } else if (parms.get("halfBrother" + lcv + "Parent").equals("mother")){
      maternalHalfSiblings.add(halfSibling);
    }
  }
  
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("halfSister")); lcv ++){
    String gender =  "Female";
    String relation = "Half-Sister"; 
    Person halfSibling = readPerson(parms, "halfSister" + lcv, relation, gender,languageStrings);
    if ( parms.get("halfSister" + lcv + "Parent").equals("father") ) {
      paternalHalfSiblings.add(halfSibling);
    } else if (parms.get("halfSister" + lcv + "Parent").equals("mother")){
      maternalHalfSiblings.add(halfSibling);
    }
  }

int halfSiblingSpace = Math.max(paternalHalfSiblings.size(), maternalHalfSiblings.size()) * 2 * (Person.personSize + Person.siblingSpacing);

// ----------------   Start Drawing -------------------------------------

int width = ((Person)people.get("paternalGrandfather")).getChildrenWidth() 
+ ((Person)people.get("maternalGrandfather")).getChildrenWidth()  
+ father.getChildrenWidth(true) + (Person.personSize + Person.siblingSpacing) + Person.spouseDistance + halfSiblingSpace + 100;

int floatUnderSpace = 0;
if (cousinCount==0){
    floatUnderSpace = Math.min(((Person)people.get("paternalGrandfather")).getChildrenWidth(),
        ((Person)people.get("maternalGrandfather")).getChildrenWidth());
}

int height = 600;
if ("1".equals(request.getAttribute("hideLegend"))){
    height = 450;
}

int imageSize = Math.max( width, 900);
if ("1".equals(request.getAttribute("debug"))){
  response.write("Image Size:" + imageSize);
}
  java.awt.image.BufferedImage image = new
  java.awt.image.BufferedImage(imageSize,height, java.awt.image.BufferedImage.TYPE_INT_RGB);
  java.awt.Graphics2D g = (java.awt.Graphics2D) image.getGraphics();

  g.setColor(java.awt.Color.WHITE);
  g.fillRect(0,0, imageSize, 600);
  g.setColor(java.awt.Color.BLACK);

  String line1 = request.getAttribute("line1") ;
  String line2 = request.getAttribute("line2") ;
  String line3 = request.getAttribute("line3") ;
  String line4 = request.getAttribute("line4") ;


  if (!"1".equals(request.getAttribute("hideLegend"))){
Person.drawLegend(g, 5,15, parms.get("selfName"), line1,request.getAttribute("language"));
  }
  
Person paternalGrandfather = (Person)people.get("paternalGrandfather");
Person maternalGrandfather = (Person)people.get("maternalGrandfather");
int startPos = paternalGrandfather.getChildrenWidth()/2 + 10 - Person.spouseDistance/2;
if (startPos < 50){
    startPos = 50;
}
// if there are no brothers or paternal uncles  and self has lots of kids we need to 
// move the drawing over.
int firstGen2Shift = 0;
int firstGen3Shift = 0;
if (firstGen2.children.size()>4){
        firstGen2Shift = (firstGen2.children.size()-2)*(Person.personSize + Person.siblingSpacing)/2;
}
if (firstGen2.children.size()>0){
    firstGen3 = (Person)(firstGen2.children.get(0));
    if (firstGen3.children.size()>4){
        firstGen3Shift = (firstGen3.children.size()-2)*(Person.personSize + Person.siblingSpacing)/2;
    }
}
startPos += firstGen2Shift + firstGen3Shift;
int yPos = 170;
if ("1".equals(request.getAttribute("hideLegend"))){
    yPos = 20;
}
paternalGrandfather.draw(g, startPos,yPos,showNames, request.getAttribute("language"));
maternalGrandfather.draw(g, paternalGrandfather.getX() + 
           paternalGrandfather.getChildrenWidth()/2 - Person.personSize - Person.siblingSpacing + 
           maternalGrandfather.getChildrenWidth()/2 + 
Math.max(father.getChildrenWidth(true)+halfSiblingSpace - floatUnderSpace, Person.spouseDistance *2 + Person.personSize)
           ,yPos,showNames,request.getAttribute("language"));

  father.spouse=mother;


  father.drawChildren(g,showNames,request.getAttribute("language"));
  if (selfTwins.size() > 1) Person.drawTwinLines(g,selfTwins);
  if (motherTwins.size() > 1) Person.drawTwinLines(g,motherTwins);
  if (fatherTwins.size() > 1) Person.drawTwinLines(g,fatherTwins);

  //  Draw half siblings

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("halfBrother")); lcv ++){
    String gender = "Male";
    String relation = "Half-Brother"; 
    Person halfSibling = readPerson(parms, "halfBrother" + lcv, relation, gender,languageStrings);

    if ( parms.get("halfBrother" + lcv + "Parent").equals("father") ) {
      halfSibling.draw(g, firstSibling.xLoc - Person.siblingSpacing-Person.personSize,firstSibling.yLoc, showNames,request.getAttribute("language"));   
      java.awt.geom.Line2D.Double upline=new java.awt.geom.Line2D.Double(halfSibling.xLoc + Person.personSize/2, halfSibling.yLoc, father.xLoc + Person.personSize/2, father.yLoc+Person.personSize);
      g.draw(upline); 
      firstSibling=halfSibling;    
    } else if (parms.get("halfBrother" + lcv + "Parent").equals("mother")){
      halfSibling.draw(g, lastSibling.xLoc + Person.siblingSpacing+Person.personSize,lastSibling.yLoc, showNames,request.getAttribute("language"));
      java.awt.geom.Line2D.Double upline=new java.awt.geom.Line2D.Double(halfSibling.xLoc + Person.personSize/2, halfSibling.yLoc, mother.xLoc + Person.personSize/2, mother.yLoc+Person.personSize);
      g.draw(upline); 
      lastSibling=halfSibling;        
    }
  }
  
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("halfSister")); lcv ++){
    String gender =  "Female";
    String relation = "Half-Sister"; 
    Person halfSibling = readPerson(parms, "halfSister" + lcv, relation, gender, languageStrings);
    if ( parms.get("halfSister" + lcv + "Parent").equals("father") ) {
      halfSibling.draw(g, firstSibling.xLoc - Person.siblingSpacing-Person.personSize,firstSibling.yLoc, showNames,request.getAttribute("language"));
      java.awt.geom.Line2D.Double upline=new java.awt.geom.Line2D.Double(halfSibling.xLoc + Person.personSize/2, halfSibling.yLoc, father.xLoc + Person.personSize/2, father.yLoc+Person.personSize);
      g.draw(upline); 
      firstSibling=halfSibling;    
    } else if (parms.get("halfSister" + lcv + "Parent").equals("mother")){
      halfSibling.draw(g, lastSibling.xLoc + Person.siblingSpacing+Person.personSize,lastSibling.yLoc, showNames, request.getAttribute("language"));   
      java.awt.geom.Line2D.Double upline=new java.awt.geom.Line2D.Double(halfSibling.xLoc + Person.personSize/2, halfSibling.yLoc, mother.xLoc + Person.personSize/2, mother.yLoc+Person.personSize);
      g.draw(upline);
      lastSibling=halfSibling;
    }
  }

  
  
  java.awt.FontMetrics m = g.getFontMetrics();
  if (line2!=null){
      g.drawString(line2, 10, 500 + m.getHeight());
  }
  if (line3!=null){
      g.drawString(line3, 10, 500 + m.getHeight()*2);
  }
  if (line4!=null){
      g.drawString(line4, 10, 500 + m.getHeight()*3);
  }
  
  //for (int lcv = 0;lcv < )
  
  // Rotate the image
 
  if ("1".equals(request.getAttribute("rotate"))){
    Iterator i = people.values().iterator();
    int rightMost = 0;
    for (Person p =(Person)(i.next());i.hasNext();p=(Person)(i.next())){
      if (p.getX()> rightMost){ rightMost = p.getX();}
    }
    rightMost = Math.max(700,rightMost + 150);
    java.awt.geom.AffineTransform tx = new java.awt.geom.AffineTransform();
    int reduceAmount = Math.max(0,image.getWidth() - rightMost);
    tx.rotate(-Math.PI/2, image.getWidth()/2,image.getWidth()/2);
    tx.translate(reduceAmount,0);
    java.awt.image.AffineTransformOp op = new java.awt.image.AffineTransformOp(tx,java.awt.image.AffineTransformOp.TYPE_BILINEAR);

    java.awt.image.BufferedImage image2 = new
    java.awt.image.BufferedImage(image.getHeight(),image.getWidth()-reduceAmount, java.awt.image.BufferedImage.TYPE_INT_RGB);
    g = (java.awt.Graphics2D) image2.getGraphics();
    g.setColor(java.awt.Color.WHITE);
    g.fillRect(0,0, image2.getWidth(), image2.getHeight());
      
    op.filter(image,image2);
    image = image2;
  }
  response.setVariable("drawWidth",(new Integer(image.getWidth())).toString());
  response.setVariable("drawHeight",(new Integer(image.getHeight())).toString());
  
  
         // Get the FILENAME attribute (throw if empty or not passed)
      String pdfFileName = request.getAttribute("PDFFILENAME") ;
      if ( pdfFileName !=null && pdfFileName.length() != 0 ){      
        try {
            PdfCreator.createPDF(pdfFileName, image);
        } catch (Error e){
            response.write(e.toString());
        }
      }
      
      String strFileName = request.getAttribute("FILENAME") ;
      if (strFileName !=null &&  strFileName.length() != 0 ){
      
     // Attempt to encode the image into a JPEG
      FileOutputStream file = null ;
      try
      {
         file = new FileOutputStream( strFileName ) ;
            PngEncoderB encoder = new PngEncoderB(image);
            encoder.setCompressionLevel(5);
            file.write(encoder.pngEncode());
      }
      catch( IOException e )
      {
         throw new Exception(
            "Error in HelloWorldGraphic: Unexpected IO exception " +
            "writing to file " + strFileName + ", " + e.getMessage() ) ;
      }
      catch( ImageFormatException e ) 
      {
         throw new Exception(
            "Error in HelloWorldGraphic: Unexpected image format " +
            "exception, " + e.getMessage() ) ;         
      }
      finally
      {
         if ( file != null ) file.close() ;   
      }  
      }
      
   }
}
