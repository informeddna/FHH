import java.awt.Image;
import javax.swing.ImageIcon;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage ;
import java.io.*;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;

public class Person { 

static Image circle;
static Image circleFill;
static Image legend;
static Image spLegend;
//static String imageRoot = "c:\\CFusionMX7\\wwwroot\\FamilyHistory\\"; 
static String imageRoot = "E:\\inetpub\\FamilyHistory\\"; 
static String spanishImageRoot = "E:\\inetpub\\FamilyHistorySpanish\\Images\\"; 
static String circleLoc = imageRoot + "circle.png";
static String circleFillLoc = imageRoot + "circle-fill.png";
static String legendLoc = imageRoot + "legend.png";
static String spLegendLoc = spanishImageRoot + "legend.png";

static {
        File f = new File(circleLoc);
        if (!f.exists()){
            System.out.println("error, could not find circle file!");
        }
     circle=new ImageIcon(circleLoc).getImage();
     
        f = new File(circleFillLoc);
        if (!f.exists()){
            System.out.println("error, could not find circle-Fill file!");
        }
     circleFill=new ImageIcon(circleFillLoc).getImage();

     f = new File(legendLoc);
        if (!f.exists()){
            System.out.println("error, could not find legend file!");
        }
     legend=new ImageIcon(legendLoc).getImage();
     
     f = new File(spLegendLoc);
        if (!f.exists()){
            System.out.println("error, could not find legend file!");
        }
     spLegend=new ImageIcon(spLegendLoc).getImage();
  }
  public static int personSize=30;
  public static int spouseDistance=120;
  public static int childrenDistance=60;
  public static int childrenBarLength=30;
  public static int siblingSpacing = 70;
 
  public static String [] shortDiseaseNames =   {"HD", "Str", "Dia", "Col", "BrC", "OvC"};
  public static String [] shortDiseaseNamesSp = {"EC", "DC",  "Dia",  "Col",  "CSe",  "COv" };
  
  public static String [] diseaseNames = {"Coronary","Stroke","Diabetes","ColonCancer","BreastCancer","OvarianCancer"};
  public static String [] baseFieldNames = {"Name","StillLiving","Gender","AdditionalDiseases","AgeAtDeath","IsTwin"};
  public static String [] fieldNames;
  
  public static java.util.HashMap englishStrings = new java.util.HashMap();
  public static java.util.HashMap spanishStrings = new java.util.HashMap();
  
  static{ 
      fieldNames = new String[diseaseNames.length *2 + baseFieldNames.length];
      for (int lcv = 0;lcv < baseFieldNames.length;lcv++){
        fieldNames[lcv] = baseFieldNames[lcv];
      }
      for (int lcv = baseFieldNames.length;lcv < baseFieldNames.length + diseaseNames.length;lcv++){
          fieldNames[lcv]= diseaseNames[lcv-baseFieldNames.length];
      }
      for (int lcv = baseFieldNames.length + diseaseNames.length ;lcv < diseaseNames.length *2 + baseFieldNames.length;lcv++){
          fieldNames[lcv]= diseaseNames[lcv-baseFieldNames.length-diseaseNames.length] + "Onset";
      }
      
      englishStrings.put("Self", "Self");
      englishStrings.put("Mother", "Mother");
      englishStrings.put("Father", "Father");
      englishStrings.put("PaternalGrandfather", "Grandfather");
      englishStrings.put("MaternalGrandfather", "Grandfather");
      englishStrings.put("PaternalGrandmother", "Grandmother");
      englishStrings.put("MaternalGrandmother", "Grandmother");
      englishStrings.put("FathersBrother", "Uncle");
      englishStrings.put("FathersSister", "Aunt");
      englishStrings.put("MothersBrother", "Uncle");
      englishStrings.put("MothersSister", "Aunt");
      englishStrings.put("Brother", "Brother");
      englishStrings.put("Sister", "Sister");
      englishStrings.put("Son", "Son");
      englishStrings.put("Daughter", "Daughter");
      englishStrings.put("Niece", "Niece");
      englishStrings.put("Nephew", "Nephew");
      englishStrings.put("MaleCousin", "Cousin");    
      englishStrings.put("FemaleCousin", "Cousin");    
      englishStrings.put("Half-Brother", "Half-Brother");    
      englishStrings.put("Half-Sister", "Half-Sister");
      englishStrings.put("ReportTitle", "My Family Health Portrait - Drawing Report");
      
      spanishStrings.put("Self", "Yo");
      spanishStrings.put("Mother", "Madre");
      spanishStrings.put("Father", "Padre");
      spanishStrings.put("PaternalGrandfather", "Abuelo");
      spanishStrings.put("MaternalGrandfather", "Abuelo");
      spanishStrings.put("PaternalGrandmother", "Abuela");
      spanishStrings.put("MaternalGrandmother", "Abuela");
      spanishStrings.put("FathersBrother", "T�o");
      spanishStrings.put("FathersSister", "T�a");
      spanishStrings.put("MothersBrother", "T�o");
      spanishStrings.put("MothersSister", "T�a");
      spanishStrings.put("Brother", "Hermano");
      spanishStrings.put("Sister", "Hermana");
      spanishStrings.put("Son", "Hijo");
      spanishStrings.put("Daughter", "Hija");
      spanishStrings.put("Niece", "Sobrina");
      spanishStrings.put("Nephew", "Sobrino");
      spanishStrings.put("MaleCousin", "Primo");    
      spanishStrings.put("FemaleCousin", "Prima");    
      spanishStrings.put("Half-Brother", "Media Hermano");    
      spanishStrings.put("Half-Sister", "Media Hermana");
      spanishStrings.put("ReportTitle", "Retrato de Salud de mi Familia - Reporte en dibujos");
  }
        
            
   String name;
   String relation;
   java.util.ArrayList children;
   Person spouse;
   String gender;
   boolean stillLiving;
   boolean isTwin;
   boolean highlighted;
   boolean drawn;
   int xLoc, yLoc;
   Person father;
   Person mother;
   boolean autoDrawChildren;
   java.util.Map fields;
   java.util.Map languageMap;
   
   public int getX() { return xLoc;}
   public int getY() { return yLoc;}
   public void setAutoDrawChildren(boolean b){autoDrawChildren = b;}
   
   Person(String name, String relation, String gender){
     this.stillLiving=true;
     this.isTwin=false;
     this.name= name;
     this.relation= relation;
     this.gender = gender;
     children= new java.util.ArrayList();
     spouse= null;
     drawn=false;
     autoDrawChildren = true;
     fields=new java.util.HashMap();
     languageMap = englishStrings;
   }   

   public void setLanguageMap(java.util.Map m){
       languageMap = m;
   }
   
   public int getChildrenWidth(){
     return getChildrenWidth(autoDrawChildren);
   }
 
   public int getChildrenWidth(boolean includeChildren){
     int ret=0;
     if (children.size()==0 || !includeChildren) return personSize + siblingSpacing;
     for (int lcv = 0;lcv < children.size();lcv++){
       ret+= ((Person)children.get(lcv)).getChildrenWidth();
     }
     return ret;
   }
/*
   private void drawChildren(java.awt.Graphics2D g, boolean showNames){
     drawChildren(g, showNames, "english");
   }
  */ 
   public void drawChildren(java.awt.Graphics2D g, boolean showNames, String language){
         setAutoDrawChildren(true);
         java.awt.geom.Line2D.Double connectorLine;
         if (spouse==this){
           connectorLine = new java.awt.geom.Line2D.Double( (xLoc + spouse.xLoc + personSize )/2 ,yLoc+personSize, 
                       (xLoc + spouse.xLoc + personSize )/2,yLoc+personSize/2 + childrenDistance);
         } else { 
           g.drawLine(xLoc + personSize,yLoc+personSize/2, spouse.xLoc,spouse.yLoc+personSize/2);
           connectorLine = new java.awt.geom.Line2D.Double( (xLoc + spouse.xLoc + personSize )/2 ,yLoc+personSize/2, 
                       (xLoc + spouse.xLoc + personSize )/2,yLoc+personSize/2 + childrenDistance);
         }
         g.draw(connectorLine);
         if (children.size()==1){
           g.drawLine( (xLoc + spouse.xLoc + personSize )/2 ,yLoc+personSize/2 + childrenDistance, 
               (xLoc + spouse.xLoc + personSize )/2,yLoc+personSize/2 + childrenDistance + childrenBarLength);
           ((Person) (children.get(0))).draw(g, (xLoc + spouse.xLoc )/2 , yLoc+personSize/2 + childrenDistance + childrenBarLength,showNames, language);
         } else {
             int lineLength = getChildrenWidth() - personSize - siblingSpacing;
             ArrayList startTwins = new ArrayList();
             ArrayList endTwins = new ArrayList();
                 if (((Person) children.get(0)).isTwin){
                     startTwins.add(((Person) children.get(0)));
                     while (startTwins.size()<children.size() && 
                         ((Person) children.get(startTwins.size())).isTwin){
                         int pos = startTwins.size();
                         startTwins.add((Person) children.get(pos));
                     }
                 }
                 if (startTwins.size()< children.size() && 
                          ((Person) children.get(children.size()-1)).isTwin   ){
                   //  endTwinCount calculations...
                   endTwins.add((Person) children.get(children.size()-1));
                     int pos = endTwins.size();
                     while (endTwins.size()<=children.size() && ((Person) children.get(children.size() - pos)).isTwin){
                         endTwins.add((Person) children.get(children.size() - pos));
                         pos=endTwins.size();
                     }
                 }

             if ( ((Person) (children.get(children.size()-1))).children.size() > 1){
                 if (((Person) children.get(0)).children.size() > 1){
                   lineLength -= ((Person) (children.get(0))).getChildrenWidth()/2 - personSize/2 - siblingSpacing/2;
                 }
                 lineLength -= ((Person) (children.get(children.size()-1))).getChildrenWidth()/2 - personSize/2 - siblingSpacing/2;
             }
           double lastChild = 0;
           for (int lcv = 0;lcv < children.size();lcv++){
               double childX = 0;
               if (lcv==0){
                 childX=connectorLine.getX1() - lineLength/2;
               } else {
                 //childX =  crossLine.getX1() + (getChildrenWidth() * lcv / (children.size()-1));
                   int lastWidth = ((Person)children.get(lcv-1)).getChildrenWidth();
                   int currentWidth = ((Person)children.get(lcv)).getChildrenWidth();
                   childX = lastChild +  lastWidth/2 + ((Person)children.get(lcv)).getChildrenWidth()/2;
               }
             java.awt.geom.Line2D.Double childBar = new java.awt.geom.Line2D.Double( 
                childX, 
                connectorLine.getY2(),
                childX, 
                connectorLine.getY2() + childrenBarLength);
             lastChild = childX;
             if (!((Person)children.get(lcv)).isTwin) {g.draw( childBar );} 
             ((Person)children.get(lcv)).draw(g,(int)(childBar.getX1() - personSize/2), 
               (int)(childBar.getY2() ), showNames,language);
           }
           if (startTwins.size()< children.size()){
             int lineStart =  ((Person) children.get(0)).xLoc + personSize/2;
             int lineEnd =  ((Person) children.get(children.size()-1)).xLoc + personSize/2;
             if (startTwins.size()>1){
                 lineStart=findMidPoint(startTwins);
             }
             if (endTwins.size()>1){
                 lineEnd=findMidPoint(endTwins);
             }
             java.awt.geom.Line2D.Double crossLine = new java.awt.geom.Line2D.Double( 
                      lineStart, connectorLine.getY2(), 
                      lineEnd , connectorLine.getY2()
             ); 
             g.draw(crossLine); 
           }
         }
   }

   public String toString(){
       return "Name: " + name + " Gender: " + gender + " Relation:" + relation;
   }
   
   public String print(String prefix){
     String ret = "";
//     System.out.print("Printing " + name);
     for ( int lcv = 0; lcv < fieldNames.length;lcv++){
       ret = ret + generate(prefix + fieldNames[lcv],  fields.get(fieldNames[lcv]).toString() );
     }
//     System.out.println("DONE");
     return ret;
   }

 public static String generate(String key, String value){
  return "<input type=\"hidden\" name=\"" + key + "\" value=\"" + value + "\">";
}

public static String generate(String key, int value){
  return "<input type=\"hidden\" name=\"" + key + "\" value=\"" + value + "\">";
}

public void writeDiseases(java.awt.Graphics2D g, String language){
    Font f = g.getFont();
    g.setFont(new Font("Tahoma", Font.TRUETYPE_FONT, 10));
    int yPos = yLoc+8;
    if (gender.equals("Female")){
    for (int lcv = 0;lcv < diseaseNames.length;lcv++){
        if ("Yes".equals(fields.get(diseaseNames[lcv]))){
if ("spanish".equals(language)){
    g.drawString(shortDiseaseNamesSp[lcv], xLoc + 8 + personSize, yPos);
} else {
    g.drawString(shortDiseaseNames[lcv], xLoc + 8 + personSize, yPos);    
}
            yPos +=9;
        }
    }
    } else {
    for (int lcv = 0;lcv < diseaseNames.length;lcv++){
        if ("Yes".equals(fields.get(diseaseNames[lcv]))){
if ("spanish".equals(language)){
            g.drawString(shortDiseaseNamesSp[lcv], xLoc - 30, yPos);
} else {
            g.drawString(shortDiseaseNames[lcv], xLoc - 30, yPos);    
}
            yPos +=9;
        }
    }        
    }
    
    g.setFont(f);
}
   
/*
   private void draw (java.awt.Graphics2D g, int x, int y, boolean showNames){
     draw(g,x,y,showNames,"english");
   }
*/   
   public void draw (java.awt.Graphics2D g, int x, int y, boolean showNames, String language){
//       System.out.println("Drawing " + name + " at " + x + ", " + y);
       if (drawn) return;
       xLoc=x;
       yLoc=y;
     if ("Male".equals(gender)){
       if (highlighted){
           g.setColor(new Color(140,211, 247));
           g.fillRect(x,y,personSize,personSize);
           g.setColor(Color.BLACK);
       }
       
       g.drawRect(x,y,personSize,personSize);
       writeDiseases(g,language);
       if (spouse!=null && spouse!=this){
          spouse.draw(g, x+spouseDistance, y, showNames, language);
       } else { spouse=this; } 
       if (children.size()>0 && autoDrawChildren){
         drawChildren(g,showNames, language);
       }

     } else {  // This is a female

       if (highlighted){
         g.drawImage(circleFill,x,y,null);
       } else {
         g.drawImage(circle,x,y,null);
       }
       writeDiseases(g,language);
       if (!autoDrawChildren) return;
       if (children.size()>0){           
         spouse=this;
         drawChildren(g,showNames,language);
       }
     }
       if (!stillLiving){
         g.setColor(Color.RED);
           g.drawLine(x+personSize,y,x, y+personSize);
         g.setColor(Color.BLACK);
       }
       g.getFontMetrics();
       g.drawString("[" + relation + "]", x-10, y + personSize + 20);
       if (showNames){
           String displayName = name;
           if (displayName.length() > 15){
               displayName = displayName.subSequence(0, 12) + "...";
           }
           g.drawString(displayName, x-10, y + personSize + 20 + g.getFontMetrics().getHeight());
       }
   }

  public static void drawLegend(java.awt.Graphics2D g, int x, int y, String name, String line1){
    drawLegend(g,x,y,name,line1, "english");
  }
  public static void drawLegend(java.awt.Graphics2D g, int x, int y, String name, String line1, String language){
    Font f = g.getFont();
    Font f2 = new Font(f.getName(), Font.BOLD, f.getSize()+2);
    g.setFont(f2);
    if ("spanish".equals(language)){
      g.drawString(spanishStrings.get("ReportTitle").toString(), x, y);
    } else {
      g.drawString(englishStrings.get("ReportTitle").toString(), x, y);
    }
    f2 = new Font(f.getName(), Font.BOLD, f.getSize());
    g.setFont(f2);
    String date = "";

    if ("spanish".equals(language)){
    java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("MMMM d, yyyy", new java.util.Locale("es")) ;
    df.applyPattern("d");
    String day = df.format(new java.util.Date());
    df.applyPattern("MMMM");
    String month = df.format(new java.util.Date());
    df.applyPattern("yyyy");
    String year = df.format(new java.util.Date());
    date = day + " de " + month + " de " + year;
    } else {
    
    java.text.SimpleDateFormat df = new java.text.SimpleDateFormat() ;
    df.applyPattern("MMMM d, yyyy");
    date = df.format(new java.util.Date());
    }
    g.drawString(name +" - "+ date, x, y+20);
    g.drawString(line1, x, y+40);
    g.setFont(f);
    if ("spanish".equals(language)){
          g.drawImage(spLegend,x,y+60,null);
    } else {
      g.drawImage(legend,x,y+60,null);
    }
  }

public static int findMidPoint(java.util.ArrayList m){
  Person firstTwin = ((Person)m.get(0));
  Person lastTwin = ((Person)m.get(m.size()-1));
  return (firstTwin.xLoc +lastTwin.xLoc )/2 + personSize/2;      
}

  public static void drawTwinLines (java.awt.Graphics2D g,java.util.ArrayList m){
  int midPoint = findMidPoint(m);
  Person firstTwin = ((Person)m.get(0));
  Person lastTwin = ((Person)m.get(m.size()-1));
  for (int lcv = 0;lcv < m.size();lcv++){
    Person twin = (Person)(m.get(lcv));
    g.drawLine(twin.xLoc + personSize/2,twin.yLoc,midPoint, twin.yLoc-childrenBarLength);
  }
  g.drawLine(  (firstTwin.xLoc + personSize/2 + midPoint)/2, firstTwin.yLoc-childrenBarLength/2,
              (lastTwin.xLoc+personSize/2 + midPoint)/2, firstTwin.yLoc-childrenBarLength/2);
}
 
  
public static void main(String [] args) throws Exception{
    System.out.println(circle);
    Person father = new Person("Younos", "father", "Male");
    Person mother = new Person("Ilhan", "Mother", "Female");
    Person bro = new Person("Haroon", "Self", "Male");
    Person self = new Person("Zeki", "Self", "Male");
    Person sis = new Person("Homi", "Self", "Male");
    sis.spouse = sis;
//    sis.autoDrawChildren = false;
    Person child1 = new Person("Amina Mariam Mokhtarzada", "Daughter", "Female");
    Person child2 = new Person("Nadia", "Neice", "Female");
    Person child3 = new Person("HaroonJr", "Nephew", "Male");
    Person child4 = new Person("Ibrahim", "Daughter", "Male");
    Person child5 = new Person("Taskeen", "Daughter", "Female");
    Person child6 = new Person("Tahereh", "Daughter", "Female");
    Person child7 = new Person("Milan", "Daughter", "Female");
    Person child8 = new Person("Sienna", "Daughter", "Female");
//    father.spouse=mother;
    father.children.add(bro);
    father.children.add(self);
//    bro.isTwin = true;
    self.isTwin = true;
    sis.isTwin = true;
    java.util.ArrayList list = new java.util.ArrayList();
//    list.add(bro);
    list.add(self);
    list.add(sis);
    father.children.add(sis);
    self.children.add(child1);    
    self.children.add(child4);    
//    self.children.add(child5);    
    self.stillLiving = false;
    sis.children.add(child6);
    sis.children.add(child2);
  //  bro.children.add(child7);
//    bro.children.add(child7);
//    bro.children.add(child8);

    java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("MMMM d, yyyy", new java.util.Locale("es")) ;
    df.applyPattern("d");
    String day = df.format(new java.util.Date());
    df.applyPattern("MMMM");
    String month = df.format(new java.util.Date());
    df.applyPattern("yyyy");
    String year = df.format(new java.util.Date());
    String date = day + " de " + month + " de " + year;
    System.out.println(date);
    
    
       BufferedImage image = 
         new BufferedImage(1000, 600, BufferedImage.TYPE_INT_RGB ) ;
      java.awt.Graphics2D g = (java.awt.Graphics2D) image.getGraphics() ;
      
    // Create a white background
      g.setColor(Color.white) ;
      g.fillRect(0, 0, image.getWidth(), image.getHeight() ) ;
      
      // Draw the Hello World string in blue
      
     // Attempt to encode the image into a JPEG
      g.setColor(Color.BLACK);
      father.setAutoDrawChildren(false);
      father.draw(g,image.getWidth()/2,100,true,"english");
      father.drawChildren(g, true, "english");
      sis.drawChildren(g, true,"english");
      //      p2.draw(g,180,100,true);
      Person.drawTwinLines(g,list);
   
      FileOutputStream file = null ;
      try
      {
          drawLegend(g, 10,10,"Zeki","Highlighted Disease: Colon Cancer");
          java.awt.geom.AffineTransform tx = new java.awt.geom.AffineTransform();
          //tx.rotate(-Math.PI/2, 200,200);
          java.awt.image.AffineTransformOp op = new java.awt.image.AffineTransformOp(tx,java.awt.image.AffineTransformOp.TYPE_BILINEAR);
          image = op.filter(image,null);
          file = new FileOutputStream( "c:\\test.png" ) ;
            PngEncoderB encoder = new PngEncoderB(image);
            encoder.setCompressionLevel(5);
            PdfCreator.createPDF("c:\\test.pdf",image);
            file.write(encoder.pngEncode());
      }
      catch( IOException e )
      {
         throw new Exception(
            "Error in HelloWorldGraphic: Unexpected IO exception " +
            "writing to file " + "test.png" + ", " + e.getMessage() ) ;
      }
   
      finally
      {
         if ( file != null ) file.close() ;   
      }  
      
    
    
}

}

/*
public Person readPerson(HttpServletRequest request, String personName, String relation, String gender){
  Person ret = new Person(request.getParameter(personName + "Name"), relation, gender);
  ret.stillLiving = !"No".equals(request.getParameter(personName + "StillLiving"));
  ret.isTwin = "Yes".equals(request.getParameter(personName + "IsTwin"));
  System.out.println(personName + request.getParameter(personName + "IsTwin"));
  return ret;
}
*/


