/*
* HelloColdFusion (very simple Java CFX)
*
* Copyright (c) 2002 Macromedia Corp. All Rights Reserved.
*
* Tag that prints a personalized greeting. The attributes of this
* tag are as follows:
*
* NAME   Name to use for printing personalized greeting.
*
* For examle, to print a greeting to "Robert", you would use the 
* following CFML code:
*
* <CFX_HelloColdFusion NAME="Robert">
*
*/

import com.allaire.cfx.* ;
import java.util.HashMap;
import java.util.Iterator;
import java.awt.image.BufferedImage ;
import com.sun.image.codec.jpeg.JPEGCodec ;
import com.sun.image.codec.jpeg.JPEGImageEncoder ;
import com.sun.image.codec.jpeg.ImageFormatException ;
import java.awt.Graphics2D;
import java.io.FileOutputStream ;
import java.io.IOException ;
import java.awt.Color ;

public class ExportFamily1 implements CustomTag
{

    class StringHashMap extends HashMap {
        public StringHashMap(){super();}
        public String get(String key){
            if (super.get(key)==null) return "";
            return super.get(key).toString();
        }
        
    }
    
    Person readPerson(StringHashMap parms, String person){
      Person p = new Person(parms.get(person+"Name"),"", parms.get(person+"Gender"));
      return p;
    }
    
  public Person readPerson(StringHashMap parms, String personName, String relation, String gender){
  Person ret = new Person(parms.get(personName + "Name"), relation, gender);
  ret.stillLiving = !"No".equals(parms.get(personName + "StillLiving"));
  ret.isTwin = "Yes".equals(parms.get(personName + "IsTwin"));
  ret.highlighted= "Yes".equals(parms.get(personName + "Highlighted"));
  for ( int lcv = 0; lcv < Person.fieldNames.length;lcv++){
    ret.fields.put(Person.fieldNames[lcv], parms.get(personName + Person.fieldNames[lcv]).trim());
  }
//  System.out.println(personName + parms.get(personName + "IsTwin"));
  return ret;
}
    
  
  
   public void processRequest( Request request, Response response ) 		
      throws Exception
   {
       boolean showNames="1".equals(request.getAttribute("showNames"));
       StringHashMap parms = new StringHashMap();

      // -------   Read Parms from query ---------
      
      Query q = request.getQuery();
      for (int lcv = 1;lcv <= q.getRowCount();lcv++){
        parms.put(q.getData(lcv,1), q.getData(lcv,2));
        if ("1".equals(request.getAttribute("debug"))){
          response.write(q.getData(lcv,1) + "=" +q.getData(lcv,2) + "<BR>");
        }
      }
      
//      if(true) return;
     
  java.util.HashMap people = new java.util.HashMap();
  java.util.ArrayList selfTwins = new java.util.ArrayList();
  java.util.HashMap motherTwins = new java.util.HashMap();
  java.util.HashMap fatherTwins = new java.util.HashMap();

//    Father's family

  people.put ("paternalGrandfather",readPerson(parms,"paternalGrandfather", "Grandfather","Male"));
  people.put ("paternalGrandmother",readPerson(parms,"paternalGrandmother", "Grandmother", "Female"));

  ((Person) people.get("paternalGrandfather")).spouse= ((Person) people.get("paternalGrandmother"));


  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("fathersSister"));lcv++){
    Person paternalAunt = readPerson(parms, "fathersSister" + lcv, "Aunt", "Female");

    people.put ("fathersSister" + lcv , paternalAunt);  
    ((Person) people.get("paternalGrandfather")).children.add(paternalAunt);
    ((Person) people.get("paternalGrandmother")).children.add(paternalAunt);
    paternalAunt.father=((Person) people.get("paternalGrandfather"));
    paternalAunt.mother=((Person) people.get("paternalGrandmother"));
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("fathersBrother"));lcv++){
    Person paternalUncle = readPerson(parms,"fathersBrother" + lcv, "Uncle", "Male");

    people.put ("fathersBrother" + lcv , paternalUncle);  
    ((Person) people.get("paternalGrandfather")).children.add(paternalUncle);
    ((Person) people.get("paternalGrandmother")).children.add(paternalUncle);
    paternalUncle.father=((Person) people.get("paternalGrandfather"));
    paternalUncle.mother=((Person) people.get("paternalGrandmother"));
  }

//  Mother's Family

  people.put ("maternalGrandfather",readPerson(parms,"maternalGrandfather","Grandfather","Male"));
  people.put ("maternalGrandmother",readPerson(parms,"maternalGrandmother", "Grandmother","Female"));

Person father = readPerson(parms, "father","Father", "Male");  
Person mother = readPerson(parms, "mother","Mother", "Female");  

people.put("father", father);
people.put("mother", mother);

father.father= ((Person) people.get("paternalGrandfather"));
father.mother= ((Person) people.get("paternalGrandmother"));
mother.father= (Person)people.get("maternalGrandfather");
mother.mother= (Person)people.get("maternalGrandmother");
((Person)people.get("maternalGrandfather")).children.add(mother);
((Person)people.get("maternalGrandmother")).children.add(mother);

  ((Person) people.get("maternalGrandfather")).spouse= ((Person) people.get("maternalGrandmother"));

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("mothersSister"));lcv++){
    Person maternalAunt = readPerson(parms,"mothersSister" + lcv , "Aunt", "Female");

    people.put ("mothersSister" + lcv , maternalAunt);  
   ((Person) people.get("maternalGrandfather")).children.add(maternalAunt);
   ((Person) people.get("maternalGrandmother")).children.add(maternalAunt);
    maternalAunt.father=((Person) people.get("maternalGrandfather"));
    maternalAunt.mother=((Person) people.get("maternalGrandmother"));
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("mothersBrother"));lcv++){
    Person maternalUncle = readPerson(parms, "mothersBrother" + lcv , "Uncle", "Male");

    people.put ("mothersBrother" + lcv , maternalUncle);
    ((Person) people.get("maternalGrandfather")).children.add(maternalUncle);
    ((Person) people.get("maternalGrandmother")).children.add(maternalUncle);
    maternalUncle.father=((Person) people.get("maternalGrandfather"));
    maternalUncle.mother=((Person) people.get("maternalGrandmother"));

  }

//  Cousins

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("maleCousin"));lcv++){
    Person cousin = readPerson(parms, "maleCousin" + lcv, "Cousin", "Male");

    people.put ("maleCousin" + lcv , cousin);  
    Person parent = ((Person) people.get(parms.get("maleCousin"+ lcv + "Parent")));
    if (parent!= null){
      parent.children.add(cousin);
      if (parent.gender.equals("Male")){
        cousin.father=parent;
      }
      if (parent.gender.equals("Female")){
        cousin.mother=parent;
      }
    }
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("femaleCousin"));lcv++){
    Person cousin = readPerson(parms, "femaleCousin" + lcv, "Cousin", "Female");

    people.put ("femaleCousin" + lcv , cousin);  
    Person parent = ((Person) people.get(parms.get("femaleCousin"+ lcv + "Parent")));
    if (parent!= null){
      parent.children.add(cousin);
      if (parent.gender.equals("Male")){
        cousin.father=parent;
      }
      if (parent.gender.equals("Female")){
        cousin.mother=parent;
      }
    }
  }




((Person)people.get("paternalGrandfather")).children.add(father); 
((Person)people.get("paternalGrandmother")).children.add(father); 


  father.spouse=mother;

//  Self family

  Person self = readPerson(parms, "self", "Self", parms.get("selfGender"));
  self.mother=mother;
  self.father=father;
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("son"));lcv++){
    Person son = readPerson(parms,"son" + lcv, "Son", "Male");
    people.put ("son" + lcv , son);
    self.children.add(son);
    if (self.gender.equals("Male")){
      son.father=self;
    }
    if (self.gender.equals("Female")){
      son.mother=self;
    }
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("daughter"));lcv++){
    Person daughter = readPerson(parms,"daughter" + lcv , "Daughter", "Female");
    people.put ("daughter" + lcv , daughter);
    self.children.add(daughter);
    if (self.gender.equals("Male")){
      daughter.father=self;
    }
    if (self.gender.equals("Female")){
      daughter.mother=self;
    }
  }

  Person firstSibling = null;
  Person lastSibling = null;
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("brother"));lcv++){
    Person brother = readPerson(parms, "brother" + lcv , "Brother", "Male");
    if (brother.isTwin) continue;
    if (firstSibling==null) firstSibling = brother;
    people.put ("brother" + lcv , brother);
    father.children.add(brother);
    mother.children.add(brother);
    brother.father=father;
    brother.mother=mother;
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("brother"));lcv++){
    Person brother = readPerson(parms, "brother" + lcv , "Brother", "Male");
    if (!brother.isTwin) continue;
    selfTwins.add(brother);
    if (firstSibling==null) firstSibling = brother;
    people.put ("brother" + lcv , brother);
    father.children.add(brother);
    mother.children.add(brother);
    brother.father=father;
    brother.mother=mother;
  }
  selfTwins.add(self);
  father.children.add(self);
  mother.children.add(self);
  lastSibling=self;
  if (firstSibling==null){firstSibling=self;}

  
  // twins first
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("sister"));lcv++){
    Person sister = readPerson(parms, "sister" + lcv ,"Sister", "Female");
    if (!sister.isTwin) continue;
    selfTwins.add(sister);
    lastSibling=sister;
    people.put ("sister" + lcv , sister);
    father.children.add(sister);
    mother.children.add(sister);
    sister.father=father;
    sister.mother=mother;
  }

  
  // non-twins
  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("sister"));lcv++){
    Person sister = readPerson(parms, "sister" + lcv ,"Sister", "Female");
    if (sister.isTwin) continue;
    lastSibling=sister;
    people.put ("sister" + lcv , sister);
    father.children.add(sister);
    mother.children.add(sister);
    sister.father=father;
    sister.mother=mother;
  }

//  Nephews

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("nephew"));lcv++){
    Person nephew = readPerson(parms, "nephew" + lcv, "Nephew", "Male");

    people.put ("nephew" + lcv , nephew);  
    Person parent = ((Person) people.get(parms.get("nephew"+ lcv + "Parent")));
    if (parent!= null){
      parent.children.add(nephew);
      if (parent.gender.equals("Male")){
        nephew.father=parent;
      }
      if (parent.gender.equals("Female")){
        nephew.mother=parent;
      }      
    }
  }

//  Nieces

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("niece"));lcv++){
    Person niece = readPerson(parms, "niece" + lcv, "Niece", "Female");

    people.put ("niece" + lcv , niece);  
    Person parent = ((Person) people.get(parms.get("niece"+ lcv + "Parent")));
    if (parent!= null){
      parent.children.add(niece);
      if (parent.gender.equals("Male")){
        niece.father=parent;
      }
      if (parent.gender.equals("Female")){
        niece.mother=parent;
      }
    }
  }


  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("halfBrother")); lcv ++){
    String gender =  "Male";
    String relation = "Half-Brother";
    Person halfSibling = readPerson(parms, "halfBrother" + lcv, relation, gender);
    people.put("halfBrother"+lcv, halfSibling);
    if (parms.get("halfBrother"+lcv + "Parent").equals("father")){
        halfSibling.father=father;
        father.children.add(halfSibling);
    } else {
        halfSibling.mother=mother;       
        mother.children.add(halfSibling);
    }
  }

  for (int lcv = 1; lcv <= Float.parseFloat(parms.get("halfSister")); lcv ++){
    String gender =  "Female";
    String relation = "Half-Sister"; 
    Person halfSibling = readPerson(parms, "halfSister" + lcv, relation, gender);
    people.put("halfSister"+lcv, halfSibling);
    if (parms.get("halfSister"+lcv + "Parent").equals("father")){
        halfSibling.father=father;
        father.children.add(halfSibling);
    } else {
        halfSibling.mother=mother;
        mother.children.add(halfSibling);
    }
  }

  
  self = (Person) (people.get(request.getAttribute("person")));
  
//Self
response.write(self.print("self"));
response.write(Person.generate("selfParent", "calculated"));

// Parents
if (self.mother != null){
  response.write(self.mother.print("mother"));
  response.write(Person.generate("motherParent", "calculated"));
  if ( self.mother.mother!=null){
      response.write(self.mother.mother.print("maternalGrandmother"));
      response.write(Person.generate("maternalGrandmotherParent", "calculated"));
  }
  if ( self.mother.father!=null){
      response.write(self.mother.father.print("maternalGrandfather"));
      response.write(Person.generate("maternalGrandfatherParent", "calculated"));
  }
}

response.write("\n");
if (self.father != null){
  response.write(self.father.print("father"));
  response.write(Person.generate("fatherParent", "calculated"));
  if ( self.father.mother!=null){
      response.write(self.father.mother.print("paternalGrandmother"));
      response.write(Person.generate("paternalGrandmotherParent", "calculated"));
  }
  if ( self.father.father!=null){
      response.write(self.father.father.print("paternalGrandfather"));
      response.write(Person.generate("paternalGrandfatherParent", "calculated"));
  }
}
response.write("\n");

//Children
  int sons=0;
  int daughters=0;
for ( int lcv = 0 ; lcv < self.children.size();lcv ++){
  if (((Person)self.children.get(lcv)).gender.equals("Male")){
    response.write(((Person)self.children.get(lcv)).print("son" + ++sons));
    response.write(Person.generate("son" + sons + "Parent","calculated"  ));    
  } else {
    response.write(((Person)self.children.get(lcv)).print("daughter" + ++daughters));
    response.write(Person.generate("daughter" + daughters + "Parent","calculated"  ));    
  }
}

//Siblings
int sisters = 0;
int brothers=0;
int halfBrothers = 0;
int halfSisters = 0;
java.util.ArrayList siblings = new java.util.ArrayList(); 
if (self.father!=null){
  for (int lcv =0; lcv < self.father.children.size();lcv++){
    Person sibling = (Person)self.father.children.get(lcv);
    if (sibling == self) continue;
    if ( self.mother == sibling.mother){
      siblings.add(sibling);
    } else {
        if (sibling.gender.equals("Male")){
          response.write(sibling.print("halfBrother" + ++halfBrothers));
          response.write(Person.generate("halfBrother" + halfBrothers + "Parent",  "father"));
        } else {
          response.write(sibling.print("halfSister" + ++halfSisters));            
          response.write(Person.generate("halfSister" + halfSisters + "Parent",  "father"));
        }
    }
  }
}
  if (self.mother!=null){
  for (int lcv =0; lcv < self.mother.children.size();lcv++){
    Person sibling = (Person)self.mother.children.get(lcv);
    if (sibling == self) continue;
    if ( self.father ==null && sibling.father==null){
      siblings.add(sibling);
    } else if (self.father != sibling.father){
        if (sibling.gender.equals("Male")){
          response.write(sibling.print("halfBrother" + ++halfBrothers));
          response.write(Person.generate("halfBrother" + halfBrothers + "Parent",  "mother"));
        } else {
          response.write(sibling.print("halfSister" + ++halfSisters));            
          response.write(Person.generate("halfSister" + halfSisters + "Parent",  "mother"));
        }
    }
  }
}

// Nieces and Nephews
int nieces = 0;
int nephews = 0;

for (int lcv = 0; lcv < siblings.size();lcv++){
    Person sibling = (Person)siblings.get(lcv);
    if (sibling.gender.equals("Male")){
        response.write(sibling.print("brother" + ++brothers));
        response.write(Person.generate("brother" + brothers + "Parent",  "calculated"));
        for ( int lcv2 = 0 ;lcv2 < sibling.children.size();lcv2++){
          Person sibChild = (Person) (sibling.children.get(lcv2));
          if (sibChild.gender.equals("Male")){
            response.write(sibChild.print("nephew" + ++nephews));
            response.write(Person.generate("nephew" + nephews + "Parent",  "brother" + brothers));
          } else {
            response.write(sibChild.print("niece" + ++nieces));
            response.write(Person.generate("niece" + nieces + "Parent",  "brother" + brothers));
          }
        }
    } else {
        response.write(sibling.print("sister" + ++sisters));
        response.write(Person.generate("sister" + sisters + "Parent","calculated"));   
        for (int lcv2 = 0 ;lcv2 < sibling.children.size();lcv2++){
          Person sibChild = (Person) (sibling.children.get(lcv2));
          if (sibChild.gender.equals("Male")){
            response.write(sibChild.print("nephew" + ++nephews));
            response.write(Person.generate("nephew" + nephews + "Parent",  "sister" + sisters));
          } else {
            response.write(sibChild.print("niece" + ++nieces));
            response.write(Person.generate("niece" + nieces + "Parent", "sister" + sisters));
          }
        }
    }
}


// Aunts/Uncles
  java.util.ArrayList fatherSibs = new java.util.ArrayList();
  java.util.ArrayList motherSibs = new java.util.ArrayList();


if (self.father!=null && self.father.father!=null){
  for (int lcv = 0; lcv< self.father.father.children.size();lcv++){
    if (self.father == self.father.father.children.get(lcv)) continue;
    fatherSibs.add(self.father.father.children.get(lcv));
  }
}
if (self.mother!=null && self.mother.father!=null){
  for (int lcv = 0; lcv< self.mother.father.children.size();lcv++){
    if (self.mother == self.mother.father.children.get(lcv)) continue;
    motherSibs.add(self.mother.father.children.get(lcv));
  }
}

int fatherBrothers=0;
int fatherSisters=0;
int motherBrothers=0;
int motherSisters=0;
int maleCousins=0;
int femaleCousins=0;

// Uncles, Aunts, and cousins

for (int lcv = 0; lcv < fatherSibs.size();lcv++){
  Person fatherSib = (Person) (fatherSibs.get(lcv));
  if (fatherSib.gender.equals("Male")){  // Paternal Uncle
    response.write(fatherSib.print("fathersBrother"+ ++fatherBrothers));
    response.write(Person.generate("fathersBrother" + fatherBrothers + "Parent", "calculated"));
      for (int lcv2 =0;lcv2 < fatherSib.children.size();lcv2++){
      Person cousin = (Person) fatherSib.children.get(lcv2);
      if (cousin.gender.equals("Male")){ 
        response.write(cousin.print("maleCousin" + ++maleCousins));
        response.write(Person.generate("maleCousin" + maleCousins + "Parent","fathersBrother" + fatherBrothers ));        
      } else { 
        response.write(cousin.print("femaleCousin" + ++femaleCousins));
        response.write(Person.generate("femaleCousin" + femaleCousins + "Parent","fathersBrother" + fatherBrothers ));        
      }
    }
  } else { // Paternal Aunt
    response.write(fatherSib.print("fathersSister"+ ++fatherSisters));
    response.write(Person.generate("fathersSister" + fatherSisters + "Parent", "calculated"));
//    System.out.print("-- " + fatherSib.name);
    for (int lcv2 =0;lcv2 < fatherSib.children.size();lcv2++){
      Person cousin = (Person) fatherSib.children.get(lcv2);
        if (cousin.gender.equals("Male")){ 
        response.write(cousin.print("maleCousin" + ++maleCousins));
        response.write(Person.generate("maleCousin" + maleCousins + "Parent","fathersSister" + fatherSisters ));        
      } else { 
        response.write(cousin.print("femaleCousin" + ++femaleCousins));
        response.write(Person.generate("femaleCousin" + femaleCousins + "Parent","fathersSister" + fatherSisters ));        
      }
    }
  }
}

for (int lcv = 0; lcv < motherSibs.size();lcv++){
  Person motherSib = (Person) (motherSibs.get(lcv));
  if (motherSib.gender.equals("Male")){
    response.write(motherSib.print("mothersBrother"+ ++motherBrothers));
    response.write(Person.generate("mothersBrother" + motherBrothers + "Parent", "calculated"));
    for (int lcv2 =0;lcv2 < motherSib.children.size();lcv2++){
      Person cousin = (Person) motherSib.children.get(lcv2);
      if (cousin.gender.equals("Male")){ 
        response.write(cousin.print("maleCousin" + ++maleCousins));
        response.write(Person.generate("maleCousin" + maleCousins + "Parent","mothersBrother" + motherBrothers ));        
      } else { 
        response.write(cousin.print("femaleCousin" + ++femaleCousins));
        response.write(Person.generate("femaleCousin" + femaleCousins + "Parent","mothersBrother" + motherBrothers ));     
      }
    }
  } else {
    response.write(motherSib.print("mothersSister"+ ++motherSisters));
    response.write(Person.generate("mothersSister" + motherSisters + "Parent", "calculated"));
    for (int lcv2 =0;lcv2 < motherSib.children.size();lcv2++){
      Person cousin = (Person) motherSib.children.get(lcv2);
      if (cousin.gender.equals("Male")){ 
        response.write(cousin.print("maleCousin" + ++maleCousins));
        response.write(Person.generate("maleCousin" + maleCousins + "Parent","mothersSister" + motherSisters ));        
      } else { 
        response.write(cousin.print("femaleCousin" + ++femaleCousins));
        response.write(Person.generate("femaleCousin" + femaleCousins + "Parent","mothersSister" + motherSisters ));      
      }
    }
  }
}

response.write(Person.generate("daughter", daughters ) );
response.write(Person.generate("son", sons ) );
response.write(Person.generate("sister", sisters ) );
response.write(Person.generate("brother", brothers ) );
response.write(Person.generate("halfBrother", halfBrothers) );
response.write(Person.generate("halfSister", halfSisters ) );

response.write(Person.generate("fathersBrother", fatherBrothers ) );
response.write(Person.generate("fathersSister", fatherSisters ) );
response.write(Person.generate("mothersBrother", motherBrothers ) );
response.write(Person.generate("mothersSister", motherSisters ) );



response.write(Person.generate("niece", nieces ) );
response.write(Person.generate("nephew", nephews ) );

response.write(Person.generate("maleCousin", maleCousins ) );
response.write(Person.generate("femaleCousin", femaleCousins ) );

      
   }
}
