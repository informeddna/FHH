import java.io.FileOutputStream;
import java.io.IOException;
import java.awt.Graphics2D;
import java.awt.Color;

import java.awt.image.BufferedImage ;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Paragraph;
import com.lowagie.text.FontFactory;

import com.lowagie.text.pdf.codec.PngImage;
import com.lowagie.text.pdf.DefaultFontMapper;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfTemplate;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.PageSize;

/*
 * PdfTest.java
 *
 * Created on October 27, 2005, 7:15 PM
 */

/**
 *
 * @author  Zeki
 */
public class PdfCreator {
    
    /** Creates a new instance of PdfTest */
    public PdfCreator() {
    }
    
    /**
     * @param args the command line arguments
     */
    static int maxWidth = 950;
    
    public static void createPDF(String filename, BufferedImage image) {
                    
           System.out.println("Images");
        
        // step 1: creation of a document-object
        Document document = new Document(PageSize.LETTER.rotate());
        
        try {
            // step 2:
            // we create a writer that listens to the document
            // and directs a PDF-stream to a file
            PdfWriter.getInstance(document, new FileOutputStream(filename));
            
            // step 3: we open the document
            document.open();
            
            // step 4:
//            document.add(new Paragraph("A picture of my dog: otsoe.jpg"));
            int written=0;
            while (image.getWidth() - written > 0){
              if (written > 0) { document.newPage();}
              BufferedImage piece = new BufferedImage(maxWidth, 600,java.awt.image.BufferedImage.TYPE_INT_RGB);
              Graphics2D g = (Graphics2D) (piece.getGraphics());
              g.fillRect(0,0, maxWidth, 600);
              g.drawImage(image, -written,0,null);

              PngEncoderB encoder = new PngEncoderB(piece);
              encoder.setCompressionLevel(5);
              byte [] bytes = encoder.pngEncode();

            
              com.lowagie.text.Image img = PngImage.getImage(bytes);
              img.scalePercent(75);
              document.add(img);
              written += maxWidth;
            }
        }
        catch(DocumentException de) {
            System.err.println(de.getMessage());
        }
        catch(IOException ioe) {
            System.err.println(ioe.getMessage());
        }
        
        // step 5: we close the document
        document.close();

    }
    public static void createPDF(java.awt.Image image) {
        System.out.println("Using the java.awt.Graphics2D-object");
        
        // step 1: creation of a document-object
        Document document = new Document();
        
        try {
            
            // step 2: creation of the writer
            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("c:\\graphics2D.pdf"));
            
            // step 3: we open the document
            document.open();
            
            // step 4: we grab the ContentByte and do some stuff with it
            
            // we create a fontMapper and read all the fonts in the font directory
            DefaultFontMapper mapper = new DefaultFontMapper();
            FontFactory.registerDirectories();
            mapper.insertDirectory("c:\\windows\\fonts");
            // we create a template and a Graphics2D object that corresponds with it
            int w = image.getWidth(null)*2;
            int h = image.getHeight(null)*2;
            PdfContentByte cb = writer.getDirectContent();
            PdfTemplate tp = cb.createTemplate(w, h);
            Graphics2D g2 = tp.createGraphics(w, h, mapper);
            tp.setWidth(w);
            tp.setHeight(h);
            
            g2.drawImage(image, 0,h, null);
            double ew = w/2;
            double eh = h/2;
            
            
            g2.setColor(Color.black);
            java.awt.Font thisFont = new java.awt.Font("Arial", java.awt.Font.PLAIN, 18);
            g2.setFont(thisFont);
            String pear = "Pear";
//            FontMetrics metrics = g2.getFontMetrics();
//            int width = metrics.stringWidth(pear);
//            g2.drawString(pear, (w - width) / 2, 20);
            g2.dispose();
            cb.addTemplate(tp, 50, 400);
            
        }
        catch(DocumentException de) {
            System.err.println(de.getMessage());
        }
        catch(IOException ioe) {
            System.err.println(ioe.getMessage());
        }
        
        // step 5: we close the document
        document.close();

    }
        
  }

