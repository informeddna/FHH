Installation Readme File

ColdFusion Settings and Details
for Installing the MFHP Web Site

Prepared by: 
David Smith
Technical Team Lead
NHGRI/NIH
February 27, 2008
 
-----------------------------
Purpose:

This document is intended to acquaint cooperating developers with the installation requirements and ColdFusion settings necessary to port the Surgeon General�s My Family Health Portrait (MFHP) web site to other servers.


-----------------------------
Server Requirements:

ColdFusion 7 or higher.  

Windows OS (preferred). ColdFusion may be run under any server operating system: Windows, Linux, Sun, etc., but the MFHP has only been thoroughly tested under Windows.

At least 2Gb of server RAM (preferred).  This code may require significant amounts of RAM due to heavy dependency on session variables, which are stored in RAM for a period of your choose (3 hours default).  If you run a multi-instance ColdFusion cluster you will need to enable session replication, but be mindful of the overhead in doing so.

No database required.  Due to OMB and HIPPA restrictions on health privacy, the MFHP site was not designed to permanently save or store user data locally.  Instead, it was designed using briefly-persistent session variables to maintain state for a period long enough to reasonably assume a person will have time to complete and save their family information.  Saving is then performed by passing all session data to an HTML file that the user must store on his or her computer.  After the session time-out period, all data is erased from the server�s RAM.

NOTE: If permission is granted to an organization to allow permanent storage of this information, it is highly desirable to convert the site into a database-driven format to allow user logins, extensibility, and additional functionality such as tying in with EMRs or other third-party web services.


-----------------------------
File Structure:

The MFHP site is made of three top-level folders:
	� FamilyHistory
	� FamilyHistorySpanish
	� FHTClasses

FamilyHistory:  Contains the primary root site, which should be mapped to your TLD.

FamilyHistorySpanish:  Contains the Spanish-version site, and must be mapped as a virtual subfolder called �/spanish/� under the root site.  If mapping is not desired, then it must be physically moved under the main �FamilyHistory� folder and renamed �spanish� so that in either case the URL http://[whatever]/spanish will point to it.  Since the Spanish site has its own set of images and help files, it tends to be easier to manage as an isolated folder.

FHTClasses:  Contains the Java code and classes that must be mapped in ColdFusion, and are required to generate the pedigree drawing.  It can sit anywhere, so long as ColdFusion knows where to look for the CFX custom tag classes.
NOTE: The Spanish site mirrors most of the functionality of the English site up to November 2006, at which point substantial changes were made to the English site only, such as support for global additional diseases that affect the entire family, the ability to preview what a user�s pedigree will look like before it is saved as a different family member, combining of the pedigree and the chart in a single report scaled to fit on a single sheet of paper, spell checking a disease, and listing disease abbreviations on the pedigree.  These were not deemed critical enough to the core purpose of the tool to have all the necessary text and instructions converted to Spanish at that time.  However, as of January 2008 the pages are in translation, but not in time for this release.


-----------------------------
Glossary:
By default, the MFHP glossary is database driven, but there is a completely static version of it called �glossarySTATIC.cfm� under the English and Spanish folders.  Please link to this static file from inside the relevant templates or else you will get an error.  It turns out the MFHP glossary was updated much less frequently than anticipated, so the need to be database-driven may be minimal.  In either case, you have the code for both, and we are happy to supply the data in spreadsheet format for easy importing into your database if asked.
  


-----------------------------
Disease Spell Check using Google:
By default, the MFHP disease spell checker (�/info/spellChecker.cfm�) points to a Google Search Appliance on the NIH network.  It is public, but we prefer that you point to your own Google Search Appliance if you have one, or construct a new method for performing disease spell check.  Otherwise, the keywords reports we receive may be skewed by your implementation.  NOTE: The Spanish version does not contain a spell checker.



-----------------------------
Application.cfm settings:

The MFHP code takes advantage of the Application.cfm framework to set path and error handling variables that are likely to be different from server to server.  In this case, the following variables need to be set to your environment for the pedigree drawing to work correctly:

<cfset imageRoot="e:\inetpub\FHTClasses\images\">
<cfset spanishImageRoot="e:\inetpub\FHTClasses\spanishImages\">
<cfset tempFileDir="e:\inetpub\FHTClasses\Temp\">

<CFSET rootURL = "https://familyhistory.hhs.gov/">

<cferror type="Request" template="errorRequest.cfm" mailto="nhgriweberrors@mail.nih.gov">
<cferror type="Exception" template="errorException.cfm" mailto="nhgriweberrors@mail.nih.gov"> 



-----------------------------
ColdFusion Administrator Settings:

Memory Variables
Enable session variables with a 3 hour minimum timeout, or whatever you desire.  Three hours gives users enough time to complete a Family History and save it.  The goal is to strike a balance between usability and persistence of personally identifying information.  These variables are also called from the Application.cfm, which override the CF Administrator settings.

 
Java Class Path
The zipped code contains a subfolder named �FHTClasses�.  It contains both the compiled and un-compiled java code that generates the pedigree .png image file served via the drawTree.cfm template.

The class path �[drive:]/[webroot]/FHTClasses� must be placed in the ColdFusion Class Path textbox under �Server Settings > Java and JVM� from the ColdFusion administrator.  You are free to change the location of the FHTClasses, so long as ColdFusion knows where to find it.

CFX Tags
Two important Java classes must be registered as CFX Tags under the ColdFusion administrator:
	� cfx_drawtree points to class name �DrawTree1�
	� cfx_exportfamily points to class name �ExportFamily1�

These classes are located under the FHTClasses folder, which is why you must set the path above.


-----------------------------
Help:

For limited help and support please contact David Smith at dcsmith@mail.nih.gov.

